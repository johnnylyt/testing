#!/usr/bin/bash
/usr/bin/fusioninventory-agent -f >/var/lib/fusioninventory-agent/cron.log 2>&1
